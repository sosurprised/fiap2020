package com.fiap.loja.TerminalConsulta;

import java.io.IOException;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletTerminalConsulta
 */
@WebServlet("/ServletTerminalConsulta")
public class ServletTerminalConsulta extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletTerminalConsulta() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int numero = Integer.parseInt(request.getParameter("numeroProduto"));
		Produto.produtos.put(401, "Camiseta branca");
		Produto.produtos.put(402, "Camiseta azul");
		Produto.produtos.put(403, "Camiseta rosa");
		String descricao = "";
		for(Map.Entry<Integer, String> entry: Produto.produtos.entrySet()) {
			if (numero == entry.getKey()) {
				descricao = entry.getValue();
			}
			descricao = "Produto não encontrado";
		}
		request.setAttribute("descricaoMostradaNaTela", descricao);
		request.getRequestDispatcher("TelaCodigoProduto.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
