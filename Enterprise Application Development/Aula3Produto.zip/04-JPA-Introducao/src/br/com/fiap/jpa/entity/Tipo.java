package br.com.fiap.jpa.entity;

public enum Tipo {
	PESSOA_FISICA, PESSOA_JURIDICA
}
