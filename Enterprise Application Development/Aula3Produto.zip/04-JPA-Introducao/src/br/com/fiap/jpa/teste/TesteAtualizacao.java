package br.com.fiap.jpa.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.jpa.entity.Categoria;
import br.com.fiap.jpa.entity.Produto;

public class TesteAtualizacao {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("oracle");
		EntityManager em = factory.createEntityManager();
		Produto produto = new Produto("Motorola", 1000, 950, null, null, Categoria.ELETRONICO);
		produto.setCodigo(2);
		em.merge(produto); //se tiver o objeto - atualiza, sen�o cria
		em.getTransaction().begin();
		em.getTransaction().commit();
		em.close();
		factory.close();
		

	}

}
