package br.com.fiap.jpa.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.jpa.entity.Categoria;
import br.com.fiap.jpa.entity.Produto;

public class TesteRefresh {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("oracle");
		EntityManager em = fabrica.createEntityManager();
		
		Produto produto = em.find(Produto.class, 2);
		System.out.println(produto.getNome());
		produto.setNome("iPhone 10 Max");
	
		em.refresh(produto);
		System.out.println(produto.getNome());
		
		em.close();
		fabrica.close();


	}

}
