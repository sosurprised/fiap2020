package br.com.fiap.jpa.entity;

	import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import com.sun.istack.NotNull;


	@Entity
	@Table (name = "TB_CLIENTE")
	@SequenceGenerator(name="produto",sequenceName = "SQ_TB_PRODUTO", allocationSize = 1)
	public class Cliente {
		
		@Id
		@Column (name = "CD_CLIENTE")
		@GeneratedValue (strategy = GenerationType.SEQUENCE, generator = "CD_CLIENTE")
		private int codigo;
		
		@Column (name = "NM_CLIENTE", length = 100)
		@NotNull
		private String nome;
		
		@Column (name = "DS_CPF", length = 11)
		private String cpf;
		
		@Temporal (TemporalType.DATE)
		@Column (name = "DT_NASCIMENTO")
		@NotNull
		private Calendar dtNascimento;
		
		@Column (name = "DS_EMAIL", length = 155)
		@NotNull
		private String email;
		
		@Column (name = "DS_TIPO")
		@NotNull
		private Tipo tipo;
		
		@Lob
		@Column (name = "IMG_CLIENTE")
		@Enumerated (EnumType.STRING)
		private byte [] imagem;

		public int getCodigo() {
			return codigo;
		}

		public void setCodigo(int codigo) {
			this.codigo = codigo;
		}

		public String getNome() {
			return nome;
		}

		public void setNome(String nome) {
			this.nome = nome;
		}

		public String getCpf() {
			return cpf;
		}

		public void setCpf(String cpf) {
			this.cpf = cpf;
		}

		public Calendar getDtNascimento() {
			return dtNascimento;
		}

		public void setDtNascimento(Calendar dtNascimento) {
			this.dtNascimento = dtNascimento;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public Tipo getTipo() {
			return tipo;
		}

		public void setTipo(Tipo tipo) {
			this.tipo = tipo;
		}

		public byte[] getImagem() {
			return imagem;
		}

		public void setImagem(byte[] imagem) {
			this.imagem = imagem;
		}
		
}


