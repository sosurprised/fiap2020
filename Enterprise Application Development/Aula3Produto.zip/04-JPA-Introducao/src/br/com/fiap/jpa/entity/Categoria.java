package br.com.fiap.jpa.entity;

public enum Categoria {
	ELETRONICO, ELETRODOMESTICO, MOVEIS, VESTUARIO
}
