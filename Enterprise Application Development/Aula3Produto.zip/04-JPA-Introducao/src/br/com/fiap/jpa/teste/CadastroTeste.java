package br.com.fiap.jpa.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.jpa.entity.Categoria;
import br.com.fiap.jpa.entity.Produto;

public class CadastroTeste {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("oracle");
		EntityManager em = fabrica.createEntityManager();
		
		Produto produto = new Produto("Celular Xiaomi", 1000, 950, null, null, Categoria.ELETRONICO);
		em.persist(produto); //cadastra o produto
		
		em.getTransaction().begin();//come�ar a transa��o
		em.getTransaction().commit();//commit no banco
		em.close();
		fabrica.close();

	}

}
