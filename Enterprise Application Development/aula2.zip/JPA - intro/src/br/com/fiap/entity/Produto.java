package br.com.fiap.entity;

import java.beans.Transient;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity 
@Table(name = "Tab_Produto")
@SequenceGenerator(name = "produto", sequenceName = "SQ_TB_PRODUTO", allocationSize = 1)
public class Produto {
	@Id
	@GeneratedValue (strategy = GenerationType.SEQUENCE, generator = "produto")
	private int id;
	@Column(name = "cd_produto", nullable = false)
	private String nome;
	@Column(name = "vl_produto", nullable = false)
	private double valor;
	
	@javax.persistence.Transient// n�o ser� mapeado para uma coluna no banco de dados
	private double valorLiquido;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}

}
