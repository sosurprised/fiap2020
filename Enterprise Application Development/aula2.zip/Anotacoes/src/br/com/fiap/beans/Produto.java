package br.com.fiap.beans;
import br.com.fiap.anotacoes.Coluna;
import br.com.fiap.anotacoes.Tabela;

@Tabela(nome = "TAB_PRODUTO")
public class Produto {
	@Coluna (nome = "cl_produto")
	private int codigo;
	
	@Coluna(nome = "nm_produto")
	private double valor;
	
	@Coluna(nome = "vl_produto")
	private String nome;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
