package br.com.fiap.beans;

import br.com.fiap.anotacoes.Tabela;

@Tabela(nome = "TAB_ALUNO")
public class Aluno {

}
