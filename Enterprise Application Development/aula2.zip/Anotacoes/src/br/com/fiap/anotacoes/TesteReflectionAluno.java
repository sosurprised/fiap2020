package br.com.fiap.anotacoes;

import java.lang.annotation.Annotation;

import br.com.fiap.beans.Aluno;
import br.com.fiap.beans.Produto;

public class TesteReflectionAluno {

	public static void main(String[] args) {
		Tabela annotation = Aluno.class.getAnnotation(Tabela.class);
		Tabela annotationP = Produto.class.getAnnotation(Tabela.class);
			System.out.println("SELECT * FROM " + annotation.nome());
			System.out.println("SELECT * FROM " + annotationP.nome());
		}

	}


