package br.com.fiap.anotacoes;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME) //at� a execu��o de c�digo
@Target({ElementType.TYPE}) //utilizada para classes e interfaces
public @interface Tabela {
	String nome();

}
