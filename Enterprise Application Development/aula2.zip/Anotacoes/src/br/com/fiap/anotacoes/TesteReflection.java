package br.com.fiap.anotacoes;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import br.com.fiap.beans.Produto;

public class TesteReflection {

	public static void main(String[] args) {
		Produto prod = new Produto();
		//Recuperar os atrubutos da classe	
		Field[] declaredFields = prod.getClass().getDeclaredFields();
		//exibir atributos
		for (Field field: declaredFields) {
			Coluna anotacao = field.getAnnotation(Coluna.class);
			System.out.println(field.getName()+ " - " + anotacao.nome() + "- Chave: " + anotacao.chave());
		}
		
		//exibir methodos
		Method[] declaredMethods = prod.getClass().getDeclaredMethods();
		for (Method method: declaredMethods) {
			System.out.println(method.getName());
		}
	}

}
