package br.com.fiap.jpa.entity;

import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.exception.EnderecoNaoExistenteException;

public interface EnderecoDAO {
	
	void cadastrar(Endereco end);
	
	void atualizar(Endereco end) throws EnderecoNaoExistenteException;
	
	Endereco pesquisar (int codigo) throws EnderecoNaoExistenteException;
	
	void deletar(int codigo) throws EnderecoNaoExistenteException;
	void commitTransacao() throws CommitException;
}
