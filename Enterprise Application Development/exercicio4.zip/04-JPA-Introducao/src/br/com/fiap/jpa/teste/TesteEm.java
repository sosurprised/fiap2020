package br.com.fiap.jpa.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.jpa.entity.Endereco;
import br.com.fiap.jpa.entity.EnderecoDAO;
import br.com.fiap.jpa.entity.EnderecoDAOImpl;
import br.com.fiap.jpa.entity.Tipo;
import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.exception.EnderecoNaoExistenteException;

public class TesteEm {

	public static void main(String[] args) throws EnderecoNaoExistenteException {
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("oracle");
		EntityManager em = fabrica.createEntityManager();		
		//criar o dao
		EnderecoDAO dao = new EnderecoDAOImpl(em);
		Endereco end = new Endereco("01532901", "Castro Alves", Tipo.RUA);
		try {
			dao.cadastrar(end);
			dao.commitTransacao();
			System.out.println("Cadastrado!");
		}catch(CommitException e) {
			System.out.println(e.getMessage());
		}
		try {
			Endereco endereco = new Endereco("01256987", "Castro Alves", Tipo.RUA);
			dao.atualizar(end);
			dao.commitTransacao();
			System.out.println("Atualizado!");
		}catch(CommitException e) {
			System.out.println(e.getMessage());
		}

		Endereco endereco = new Endereco("01256987", "Castro Alves", Tipo.RUA);
		dao.pesquisar(end.getCodigo());
		System.out.println("Achei!");
		try {
			dao.deletar(end.getCodigo());
			dao.commitTransacao();
			System.out.println("Deletado!");
		}catch(EnderecoNaoExistenteException|CommitException e) {
			System.out.println(e.getMessage());
		}


		
		em.close();
		fabrica.close();
		

	}

}
