package br.com.fiap.jpa.entity;

import java.util.Calendar;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@SequenceGenerator(name = "end", sequenceName = "SQ_TB_ENDERECO", allocationSize = 1)
public class Endereco {
	

	@Id
	@GeneratedValue(generator = "end", strategy = GenerationType.SEQUENCE)
	@Column (name ="nr_codigo")
	private int codigo;	
	
	@Column(name = "ds_cep", length = 8, nullable = true)
	private String cep;
	
	@Column (name = "ds_logradouro", length = 50, nullable = true)
	private String logradouro;
	
	@Enumerated
	@Column (name = "ds_tipo", nullable = true)
	private Tipo tipo;
	
	public Endereco() {}
	public Endereco(String cep, String logradouro, Tipo tipo) {
		super();
		this.cep = cep;
		this.logradouro = logradouro;
		this.tipo = tipo;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getLogradouro() {
		return logradouro;
	}

	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	public Tipo getTipo() {
		return tipo;
	}

	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}

	public Calendar getDataCadatro() {
		return dataCadatro;
	}

	public void setDataCadatro(Calendar dataCadatro) {
		this.dataCadatro = dataCadatro;
	}

	//@CreationTimestamp 
	@Column (name = "dt_cadastro", nullable = true)
	@Temporal (TemporalType.TIMESTAMP)
	private Calendar dataCadatro;
}
