package br.com.fiap.jpa.entity;

public enum Tipo {
	AVENIDA, RUA
}
