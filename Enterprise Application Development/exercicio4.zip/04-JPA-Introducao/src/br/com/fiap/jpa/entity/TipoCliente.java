package br.com.fiap.jpa.entity;

public enum TipoCliente {

	PESSOA_FISICA, PESSOA_JURIDICA
	
}