package br.com.fiap.jpa.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Teste {

	public static void main(String[] args) {
		//Instanciar a f�brica de Entity Manager
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("oracle");
		
		//Obter um objeto de Entity Manager
		EntityManager em = fabrica.createEntityManager();
		
		
		em.close();
		fabrica.close();
	}
	
}