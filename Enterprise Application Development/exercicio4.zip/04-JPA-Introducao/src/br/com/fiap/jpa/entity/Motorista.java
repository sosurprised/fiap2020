package br.com.fiap.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "motorista", sequenceName = "SQ_TB_MOTORISTA", allocationSize = 1)
public class Motorista {
	decimal carteira;
	
}

