package br.com.fiap.jpa.entity;

import javax.persistence.EntityManager;

import br.com.fiap.jpa.exception.CommitException;
import br.com.fiap.jpa.exception.EnderecoNaoExistenteException;

public class EnderecoDAOImpl implements EnderecoDAO {	
	
	private EntityManager em;
	
	public EnderecoDAOImpl(EntityManager em) {
		this.em = em;
	}
	
	@Override
	public void cadastrar(Endereco end)  { 	
			em.persist(end);

 

	}

	@Override
	public void atualizar(Endereco end) throws EnderecoNaoExistenteException{
		pesquisar(end.getCodigo());
		em.merge(end);


		
	}

	@Override
	public Endereco pesquisar(int codigo) throws EnderecoNaoExistenteException{
		Endereco endereco = em.find(Endereco.class, codigo); 
		if(endereco == null)
			throw new EnderecoNaoExistenteException();
		return endereco;
	}

	@Override
	public void deletar(int codigo) throws EnderecoNaoExistenteException {
		Endereco endereco = pesquisar(codigo);
		em.remove(endereco);

	}

	@Override
	public void commitTransacao() throws CommitException{
		try {
			em.getTransaction().begin();
			em.getTransaction().commit();
		}catch(Exception e){
			e.printStackTrace();
			em.getTransaction().rollback();
			throw new CommitException(e.getMessage());
		}
	
		
	}



}
