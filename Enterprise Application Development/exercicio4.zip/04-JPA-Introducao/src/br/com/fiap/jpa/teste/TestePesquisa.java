package br.com.fiap.jpa.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import br.com.fiap.jpa.entity.Produto;

public class TestePesquisa {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("oracle");
		EntityManager em = fabrica.createEntityManager();
		
		//Pesquisar o produto de c�digo 1 
		Produto prod = em.find(Produto.class, 3);
	
		System.out.println(prod.getNome());
		System.out.println(prod.getValorLiquido());
		
		//Alterar o valor do produto
		prod.setValor(1500);
		
		em.getTransaction().begin(); //come�a a transa��o
		em.getTransaction().commit();
		
		em.close();
		fabrica.close();
	}
	
}
