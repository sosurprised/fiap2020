package br.com.fiap.exception;

public class SaldoInsuficienteException extends Exception {

	public SaldoInsuficienteException() {
		super();
	}

	public SaldoInsuficienteException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SaldoInsuficienteException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SaldoInsuficienteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SaldoInsuficienteException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
	
}